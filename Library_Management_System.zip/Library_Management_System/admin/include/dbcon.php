<?php
mysql_select_db('lms',mysql_connect('localhost:444','root',''))or die(mysql_error());
?>