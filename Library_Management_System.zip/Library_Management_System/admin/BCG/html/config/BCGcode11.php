<?php
$classFile = 'BCGcode11.barcode.php';
$className = 'BCGcode11';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '5.0.2';
?>